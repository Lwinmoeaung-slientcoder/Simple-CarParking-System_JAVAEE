-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 08, 2020 at 05:15 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.2.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `carparking`
--

-- --------------------------------------------------------

--
-- Table structure for table `carinfo`
--

CREATE TABLE `carinfo` (
  `id` int(255) NOT NULL,
  `carnumber` varchar(255) NOT NULL,
  `time` time(6) NOT NULL,
  `location` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

--
-- Dumping data for table `carinfo`
--

INSERT INTO `carinfo` (`id`, `carnumber`, `time`, `location`) VALUES
(11, '0000', '22:19:47.000000', 'A'),
(12, '254', '22:44:10.000000', 'A'),
(13, 'g', '22:50:53.000000', 'A'),
(16, '8', '23:36:02.000000', 'A'),
(17, '86', '23:36:02.000000', 'A');

-- --------------------------------------------------------

--
-- Table structure for table `exitdb`
--

CREATE TABLE `exitdb` (
  `id` int(255) NOT NULL,
  `carno` varchar(255) NOT NULL,
  `exittime` time(6) NOT NULL,
  `zone` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

--
-- Dumping data for table `exitdb`
--

INSERT INTO `exitdb` (`id`, `carno`, `exittime`, `zone`) VALUES
(2, '237', '21:49:34.000000', 'Z3'),
(3, '147', '22:17:13.000000', 'null'),
(4, '7', '23:32:07.000000', 'Z1'),
(5, '1234', '23:36:20.000000', 'Z1');

-- --------------------------------------------------------

--
-- Table structure for table `zone`
--

CREATE TABLE `zone` (
  `id` int(255) NOT NULL,
  `zone` varchar(255) NOT NULL,
  `count` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

--
-- Dumping data for table `zone`
--

INSERT INTO `zone` (`id`, `zone`, `count`) VALUES
(8, 'Z1', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `carinfo`
--
ALTER TABLE `carinfo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exitdb`
--
ALTER TABLE `exitdb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zone`
--
ALTER TABLE `zone`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `carinfo`
--
ALTER TABLE `carinfo`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `exitdb`
--
ALTER TABLE `exitdb`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `zone`
--
ALTER TABLE `zone`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
