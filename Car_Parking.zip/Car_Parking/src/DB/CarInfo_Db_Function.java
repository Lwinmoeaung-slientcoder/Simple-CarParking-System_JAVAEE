package DB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import Model.CarInfo;
import Model.Login;

public class CarInfo_Db_Function {

	private static String sql="";
	private static Connection con;
	private final static String connectionString ="jdbc:mysql://localhost/carparking";
	private final static String username ="root";
	private final static String password ="";
	private static Statement stmt = null;
	private static ResultSet rs = null;
	
	public static void Db_Connection() {
		
		try {	
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(connectionString, username, password);	
			System.out.println("Database Connection Success");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.err.println("Driver Error");
		} catch (SQLException e) {
			e.printStackTrace();
			System.err.println("Connection error");
		}
	}
	public static void Insert(CarInfo ci) {
		Db_Connection();
		
		String carno=ci.getCar_no();
		String entrytime=ci.getTime();
		String location=ci.getlocation();
		
		try {
			Db_Connection();
			 sql="INSERT INTO carinfo(carnumber,time,location) VALUES ('"+carno+"','"+entrytime+"','"+location+"')";
			 System.out.println(sql);
			 stmt = con.createStatement();
			stmt.executeUpdate(sql);
			System.out.println("Query Success");
			 
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Sql Query error ");
		
		}finally {
			disconnect();
		}
		return;
		
	}
	
	public static void disconnect() {
	if (con != null) {
		con = null;
	}
	if (stmt != null) {
		stmt = null;
	}
	if (rs != null) {
		stmt = null;
	}
}
	
}
