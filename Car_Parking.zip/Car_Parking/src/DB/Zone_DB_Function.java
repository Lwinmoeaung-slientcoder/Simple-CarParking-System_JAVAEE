package DB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import Model.zone_Model;

public class Zone_DB_Function {
	private static String sql="";
	private static Connection con;
	private final static String connectionString ="jdbc:mysql://localhost/carparking";
	private final static String username ="root";
	private final static String password ="";
	private static Statement stmt = null;
	private static ResultSet rs = null;
	private static PreparedStatement ps=null;
	
	
	public static void Db_Connection() {
		
		try {	
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(connectionString, username, password);	
		//	System.out.println("Database Connection Success");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.err.println("Driver Error");
		} catch (SQLException e) {
			e.printStackTrace();
			System.err.println("Connection error");
		}
	}
	public static int Insert(zone_Model zm) {
	String zone=zm.getZone();
	int count=zm.getCount();
	
	try {
		Db_Connection();
		 sql="INSERT INTO zone(zone,count) VALUES ('"+zone+"','"+count+"')";
		 stmt = con.createStatement();
		stmt.executeUpdate(sql);
		System.out.println("Insert QUERY Success");
		 
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		System.out.println("Sql Query error ");
	
	}finally {
		disconnect();
	}
	return 0;
}
	
	public static int Update(zone_Model zm) {
		String zone=zm.getZone();
		int count=zm.getCount()+1;
		
		try {
			Db_Connection();
			 sql="UPDATE zone SET count='"+count+"' WHERE zone='"+zone+"'";
			 stmt = con.createStatement();
			stmt.executeUpdate(sql);
			System.out.println("Update QUERY Success");
			 
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Sql Query error ");
		
		}finally {
			disconnect();
		}
		return 0;
	}
	
	public static void CheckZone(zone_Model zm) {
			Db_Connection();
		
		String zone=zm.getZone();
		
		try {
			Db_Connection();
			 sql="SELECT * FROM zone where zone='"+zone+"'";
			 stmt = con.createStatement();
			 rs=stmt.executeQuery(sql);
			if(rs.next()) {
				if(rs.getInt(3)>=3) {
					zm.setCheck("false");
					System.out.println("Car parking is full");
				}else {
					zm.setCount(rs.getInt(3));
					Update(zm);
				}
				
				
			
			}else {
				Insert(zm);
			}
			 
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Sql Query error ");
		
		}finally {
			disconnect();
		}
		return;
		
	}
	
	public static void disconnect() {
	if (con != null) {
		con = null;
	}
	if (stmt != null) {
		stmt = null;
	}
	if (rs != null) {
		stmt = null;
	}
}
}
