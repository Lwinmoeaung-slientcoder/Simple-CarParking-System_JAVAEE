package DB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import Model.CarInfo;
import Model.CarInfo;
import Model.Exit;
import Model.ResultModel;
import Model.zone_Model;

public class Result_DB_Function {
	private static String sql,update_sql="";
	private static Connection con;
	private final static String connectionString ="jdbc:mysql://localhost/carparking";
	private final static String username ="root";
	private final static String password ="";
	private static Statement stmt = null;
	private static ResultSet rs = null;
	private static String car_no,zone,exittime;
	static zone_Model zm=new zone_Model();
	
	public static void Db_Connection() {
		
		try {	
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(connectionString, username, password);	
			System.out.println("Database Connection Success");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.err.println("Driver Error");
		} catch (SQLException e) {
			e.printStackTrace();
			System.err.println("Connection error");
		}
	}

	public static ResultModel CarInfoselect(ResultModel rm) throws SQLException {
		 car_no=rm.getCarno();
       sql="SELECT * FROM carinfo WHERE carnumber='"+car_no+"'";

		try {
			Db_Connection();
			stmt = con.prepareStatement(sql);
			rs = stmt.executeQuery(sql) ;
							while(rs.next()) {
								rm.setEntrytime(rs.getString("time"));
								}
							ExitinfoSelect(rm);
							System.out.println("entry"+rm.getEntrytime());
							System.out.println("exit"+rm.getExittime());
							
			}finally {
				disconnect();
			}
			return rm;
	}
	public static void Delete() {
		Db_Connection();
		List<Exit> ulist=Exit_Db_Function.ShowAll();
		for(Exit u : ulist){
		car_no=((Exit) u).getCar_no();
		exittime=((Exit) u).getTime();
		zone=((Exit) u).getZone();
		}
		System.out.println("Delete :"+zone);
		int count;
		
		
		sql="SELECT * FROM carinfo WHERE carnumber='"+car_no+"'";
	//	System.out.println("Delete +"+sql);
		try {
			Db_Connection();
			stmt = con.prepareStatement(sql);
			rs = stmt.executeQuery(sql) ;
//			if(rs.next()) {
					sql="DELETE FROM carinfo WHERE carnumber='"+car_no+"'";
					stmt = con.createStatement();
					stmt.executeUpdate(sql);
					
				
					
					String select="SELECT * FROM zone WHERE zone='"+zone+"'";
					System.out.println(select);
					stmt = con.prepareStatement(select);
					rs = stmt.executeQuery(select) ;
							while(rs.next()) {
									count=rs.getInt("count")-1;
									//System.out.println(count);
									update_sql="UPDATE zone SET count='"+count+"' WHERE zone='"+zone+"'";
									System.out.println(update_sql);
									 stmt = con.createStatement();
									stmt.execute(update_sql);
									
//									ex.setCar_no(car_no);
//									ex.setTime(exittime);
//							//		Insert(ex);
//								}
//					}else {
//						ex.setCheck("false");
					}
			
			
		
			 
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Sql Query error ");
		
		}finally {
			disconnect();
		}
		return;
		
	}
	
	public static void ExitinfoSelect(ResultModel rm) throws SQLException {
		String carno=rm.getCarno();
	       sql="SELECT * FROM exitdb WHERE carno='"+carno+"'";
			
			try {
				Db_Connection();
				stmt = con.prepareStatement(sql);
				rs = stmt.executeQuery(sql) ;		
								while(rs.next()) {
									rm.setExittime(rs.getString("exittime"));
									}
								
				}finally {
					disconnect();
				}
				return;
	}
		
		

	public static void disconnect() {
	if (con != null) {
		con = null;
	}
	if (stmt != null) {
		stmt = null;
	}
	if (rs != null) {
		stmt = null;
	}
}
}
