package DB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import Model.CarInfo;
import Model.CarInfo;
import Model.Exit;
import Model.zone_Model;

public class Exit_Db_Function<User> {
	private static String sql,update_sql="";
	private static Connection con;
	private final static String connectionString ="jdbc:mysql://localhost/carparking";
	private final static String username ="root";
	private final static String password ="";
	private static Statement stmt = null;
	private static ResultSet rs = null;
	private static String carno;
	static zone_Model zm=new zone_Model();
	
	public static void Db_Connection() {
		
		try {	
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(connectionString, username, password);	
			System.out.println("Database Connection Success");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.err.println("Driver Error");
		} catch (SQLException e) {
			e.printStackTrace();
			System.err.println("Connection error");
		}
	}

	public static List<Exit> ShowAll() {
		try {
			Db_Connection();
			//System.out.println("sHOWaLL : "+carno);
				String sql="select * from exitdb where carno='"+carno+"'";
				stmt = con.createStatement();
				stmt.executeQuery(sql);
				ResultSet rs=stmt.executeQuery(sql);
				if(rs.next()) {
				ArrayList<Exit> ulist = new ArrayList<Exit>();
				while (rs.next()) {
					Exit u = new Exit();
					u.setId(rs.getInt(1));
					u.setCar_no(rs.getString("carno"));
					u.setTime(rs.getString("exittime"));
					u.setZone(rs.getString("zone"));
				//	System.out.println("sHOW_aLL :"+rs.getString("zone"));
					ulist.add(u);
				}
				return ulist;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Sql S error ");
		
		}finally {
			disconnect();
		}
		return null;
	}
	public static void Insert(Exit ex) {
		Db_Connection();
		carno=ex.getCar_no();
		String exittime=ex.getTime();
		String zone=ex.getZone();
		
		try {
			Db_Connection();
			sql="SELECT * FROM carinfo WHERE carnumber='"+carno+"'";
			System.out.println(sql);
			stmt = con.prepareStatement(sql);
			rs = stmt.executeQuery(sql) ;
			if(rs.next()) {
			 sql="INSERT INTO exitdb(carno,exittime,zone) VALUES ('"+carno+"','"+exittime+"','"+zone+"')";
			 System.out.println(sql);
			 stmt = con.createStatement();
			stmt.executeUpdate(sql);
			System.out.println("Query Success");
		}else {
			
			ex.setCheck("false");
		}
			 
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Sql Query error ");
		
		}finally {
			disconnect();
		}
		return;
	}
		
		

	public static void disconnect() {
	if (con != null) {
		con = null;
	}
	if (stmt != null) {
		stmt = null;
	}
	if (rs != null) {
		stmt = null;
	}
}
}
