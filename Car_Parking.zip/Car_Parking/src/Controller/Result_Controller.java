package Controller;

import java.io.IOException;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DB.Exit_Db_Function;
import DB.Result_DB_Function;
import Model.Exit;
import Model.ResultModel;

/**
 * Servlet implementation class Result_Controller
 */
@WebServlet("/Result_Controller")
public class Result_Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;
	java.util.Date entrytime;
	java.util.Date exittime;
	long minprice=50;
	long hrprice=3000;
	long totalHr,totalMin,totalresult;
	String carno,exit,zone;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Result_Controller() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String carno=request.getParameter("carno");

		
	ResultModel rm=new ResultModel();
	rm.setCarno(carno);
	try {
		Result_DB_Function.CarInfoselect(rm);
		
		SimpleDateFormat format = new SimpleDateFormat("HH:mm");

		try {
			entrytime = format.parse(rm.getEntrytime());
			exittime = format.parse(rm.getExittime());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		long difference = exittime.getTime() - entrytime.getTime(); 
		long diffMinutes = difference / (60 * 1000) % 60;
		long diffHours = difference / (60 * 60 * 1000) % 24;
		
		
		totalHr=diffHours*hrprice;
		totalMin=diffMinutes*minprice;
		totalresult=totalHr+totalMin;
		DateFormat dateFormat = new SimpleDateFormat("HH:mm");  
        String entry = dateFormat.format(entrytime);  
        String exit = dateFormat.format(exittime);  
		
	//	System.out.println(totalresult);
		request.setAttribute("tax", totalresult);
		request.setAttribute("entrytime", entry);
		request.setAttribute("exittime", exit);
		request.setAttribute("carno", carno);
		Result_DB_Function.Delete();
		RequestDispatcher rd = getServletContext().getRequestDispatcher("/Result.jsp");
		rd.forward(request, response);
		
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} 
	
}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
