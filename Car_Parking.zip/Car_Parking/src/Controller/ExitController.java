package Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DB.CarInfo_Db_Function;
import DB.Exit_Db_Function;
import Model.Exit;

/**
 * Servlet implementation class ExitController
 */
@WebServlet("/ExitController")
public class ExitController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ExitController() {																																											
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String car_no=request.getParameter("carno");
		String exittime=request.getParameter("time");
		String zone=request.getParameter("zone");
		
		Exit ex=new Exit();
		ex.setCar_no(car_no);
		ex.setTime(exittime);
		ex.setZone(zone);
		System.out.println("Exit _Zone :"+ex.getZone());
		//Exit_Db_Function.Delete(ex);
		Exit_Db_Function.Insert(ex);
		Exit_Db_Function.ShowAll();
		if(ex.getCheck().equals("true")) {
			 response.sendRedirect("Result_Controller?carno="+ex.getCar_no()+"");
		}else {
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			request.setAttribute("error", "Wrong Car Number!!!");
			RequestDispatcher rd = getServletContext().getRequestDispatcher("/Exit.jsp");
			rd.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
