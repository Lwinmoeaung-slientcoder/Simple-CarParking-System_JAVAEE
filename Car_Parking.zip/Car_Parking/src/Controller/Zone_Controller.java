package Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DB.Zone_DB_Function;
import Model.zone_Model;

/**
 * Servlet implementation class zonecheck
 */
@WebServlet("/Zone_Controller")
public class Zone_Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static int count =0;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Zone_Controller() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String zone=request.getParameter("zone");
		String bt=request.getParameter("bt");
		String location=request.getParameter("location");
		zone_Model zm=new zone_Model();
		zm.setZone(zone);
		zm.setCount(1);
		
		if(bt.equals("Check")) {
			
			Zone_DB_Function.CheckZone(zm);
			
			if(zm.getCheck().equals("true")) {
				 response.sendRedirect("Exit.jsp?zone='"+zone+"'");
			//	response.sendRedirect("zone.jsp");
				
			}
			else {
				count=count+1;
				if(count>4) {
					count=0;
				}
				response.setContentType("text/html");
				PrintWriter out = response.getWriter();
				String[] zones = {"A", "B", "C", "D"};
				request.setAttribute("check", count);
				for(int i=0;i<zones.length;i++) {
					if(count==0) {
						request.setAttribute("nearzone", zones[0] +" is nearest zone");
						request.setAttribute("error", "Car Parking in Full in this Zone..Choose another zone");
						RequestDispatcher rd = getServletContext().getRequestDispatcher("/zone.jsp");
						rd.forward(request, response);
						return;
					}else if(count==1) {
						request.setAttribute("nearzone", zones[1] +" is nearest zone");
						request.setAttribute("error", "Car Parking in Full in this Zone..Choose another zone");
						RequestDispatcher rd = getServletContext().getRequestDispatcher("/zone.jsp");
						rd.forward(request, response);
						return;
					}else if(count==2) {
						request.setAttribute("nearzone", zones[2] +" is nearest zone");
						request.setAttribute("error", "Car Parking in Full in this Zone..Choose another zone");
						RequestDispatcher rd = getServletContext().getRequestDispatcher("/zone.jsp");
						rd.forward(request, response);
						return;
					}else if(count==3) {
						request.setAttribute("nearzone", zones[3] +" is nearest zone");
						request.setAttribute("error", "Car Parking in Full in this Zone..Choose another zone");
						RequestDispatcher rd = getServletContext().getRequestDispatcher("/zone.jsp");
						rd.forward(request, response);
						return;
					}else {
						request.setAttribute("nearzone", "All Zones are full now");
						request.setAttribute("error", "Car Parking in Full in this Zone..Choose another zone");
						RequestDispatcher rd = getServletContext().getRequestDispatcher("/zone.jsp");
						rd.forward(request, response);
						return;
					}
					
				}
			
			
				//response.sendRedirect("zone.jsp");
			}
			
		}else {
		
			 response.sendRedirect("Car_Info.jsp?");
		}
		
	
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
