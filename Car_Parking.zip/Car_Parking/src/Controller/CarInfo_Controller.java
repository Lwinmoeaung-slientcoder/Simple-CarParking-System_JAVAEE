package Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DB.CarInfo_Db_Function;
import Model.CarInfo;

/**
 * Servlet implementation class CarInfo_Controller
 */
@WebServlet("/CarInfo_Controller")
public class CarInfo_Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CarInfo_Controller() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String carno=request.getParameter("carno");
		String time=request.getParameter("time");
		String location=request.getParameter("location");
		String button=request.getParameter("bt");
		
		
	
			CarInfo ci=new CarInfo();
			ci.setCar_no(carno);
			ci.setTime(time);
			ci.setlocation(location);
			
			CarInfo_Db_Function.Insert(ci);
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			request.setAttribute("nearest", location);
			RequestDispatcher rd = getServletContext().getRequestDispatcher("/zone.jsp");
			rd.forward(request, response);
			//response.sendRedirect("zone.jsp");

//		CarInfo_Db_Function.Db_Connection();

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
