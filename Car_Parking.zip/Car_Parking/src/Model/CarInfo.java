package Model;

public class CarInfo {
		private String car_no="";
		private String time="";
		private String location="";
	
		public String getCar_no() {
			return car_no;
		}
		public void setCar_no(String car_no) {
			this.car_no = car_no;
		}
		public String getTime() {
			return time;
		}
		public void setTime(String time) {
			this.time = time;
		}
		public String getlocation() {
			return location;
		}
		public void setlocation(String location) {
			this.location = location;
		}
}
