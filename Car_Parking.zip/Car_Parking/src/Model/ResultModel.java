package Model;

public class ResultModel {
String carno;
String entrytime;
String exittime;
public String getCarno() {
	return carno;
}
public void setCarno(String carno) {
	this.carno = carno;
}
public String getEntrytime() {
	return entrytime;
}
public void setEntrytime(String entrytime) {
	this.entrytime = entrytime;
}
public String getExittime() {
	return exittime;
}
public void setExittime(String exittime) {
	this.exittime = exittime;
}

}
